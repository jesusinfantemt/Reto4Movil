package usa.sesion15.reto4.Vista;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import reto4.R;

public class Fragment_Inicio extends Fragment {

    /**
     * Button
     */
    Button boton1;

    TextView texto1;

    View v;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment__inicio, container, false);
        boton1 = (Button) v.findViewById(R.id.botoninfo);
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                texto1.setText("");
                Toast.makeText(getContext(),"Función en próximas versiones", Toast.LENGTH_SHORT).show();
                //System.out.println(R.drawable.producto1);
                //System.out.println(R.drawable.producto3);
                //System.out.println(R.drawable.producto2);
                //System.out.println(R.drawable.domicilio);
                //System.out.println(R.drawable.estampado);
                //System.out.println(R.drawable.confeccion);
                //System.out.println(R.drawable.sucursal11);
                //System.out.println(R.drawable.sucusal12);
                //System.out.println(R.drawable.sucursal13);
            }
        });

        texto1 = (TextView) v.findViewById(R.id.texto1);
        return v;
    }



}