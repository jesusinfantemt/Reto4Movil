package usa.sesion15.reto4.Modelo.BaseDatos;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MotorBaseDatosSQLite extends SQLiteOpenHelper {

    public MotorBaseDatosSQLite(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
       //TABLA FAVORITOS
        db.execSQL("CREATE TABLE IF NOT EXISTS favoritos (img TEXT, descripcion1 TEXT,descripcion2 TEXT, descripcion3 TEXT)");
        //---- RegistroS

        //TABLA PRODUCTOS
        db.execSQL("CREATE TABLE productos (img TEXT, descripcion1 TEXT,descripcion2 TEXT, descripcion3 TEXT)");
        //---- Registros
        db.execSQL("INSERT INTO productos VALUES ('android.resource://usa.sesion15.reto4/2131165368','Marca: AlpinStar','Colores: Blanco, negro y azul','Material: Cuero y Lino')");
        db.execSQL("INSERT INTO productos VALUES ('android.resource://usa.sesion15.reto4/2131165370', 'Marca: Chevignon','Colores: Negro y blanco', 'Material: Cuero')");
        db.execSQL("INSERT INTO productos VALUES ('android.resource://usa.sesion15.reto4/2131165369', 'Marca: GirBaud','Colores: Verde, azul, rosa','Material: Lino')");

        //TABLA SERVICIOS
        db.execSQL("CREATE TABLE servicios (img TEXT, descripcion1 TEXT,descripcion2 TEXT, descripcion3 TEXT)");
        //---- Registros
        db.execSQL("INSERT INTO servicios VALUES ('android.resource://usa.sesion15.reto4/2131165290', 'Domicilios','Sin costo de envío','Pagos contraentrega')");
        db.execSQL("INSERT INTO servicios VALUES ('android.resource://usa.sesion15.reto4/2131165291', 'Estampado','Estampamos tus diseños','Ofrecemos chaquetas únicas')");
        db.execSQL("INSERT INTO servicios VALUES ('android.resource://usa.sesion15.reto4/2131165284', 'Confección','Diseños únicos a buen precio','Mas de 10 tipos de telas')");

        //TABLA SUCURSALES
        db.execSQL("CREATE TABLE sucursales (img TEXT, descripcion1 TEXT,descripcion2 TEXT, descripcion3 TEXT)");
        //---- Registros
        db.execSQL("INSERT INTO sucursales VALUES ('android.resource://usa.sesion15.reto4/2131165375', 'Sucursal Central','Bogotá - Cll #3 5- 32','Telefono: 3123322156')");
        db.execSQL("INSERT INTO sucursales VALUES ('android.resource://usa.sesion15.reto4/2131165379', 'Sucursal Alterna 1','Medellín - Av.Palacé #52-2','Telefono: 3134675544')");
        db.execSQL("INSERT INTO sucursales VALUES ('android.resource://usa.sesion15.reto4/2131165376', 'Sucursal Alterna 2','Tunja - Cll. 19 #8-131','Telefono: 3565453332')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //db.execSQL("DROP TABLE favoritos");
        db.execSQL("DROP TABLE productos");
        db.execSQL("DROP TABLE servicios");
        db.execSQL("DROP TABLE sucursales");
        onCreate(db);

    }
}
