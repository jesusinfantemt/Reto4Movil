package usa.sesion15.reto4.Vista;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;

import reto4.R;
import usa.sesion15.reto4.Modelo.Adaptador;
import usa.sesion15.reto4.Modelo.BaseDatos.MotorBaseDatosSQLite;
import usa.sesion15.reto4.Modelo.Entidad;

public class Fragment_Favoritos extends Fragment {

    View v;
    ListView listaFavoritos;
    Adaptador adaptador;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment__favoritos, container, false);
        //-----------------------------------------------------------------------------
        listaFavoritos = (ListView) v.findViewById(R.id.lista_favoritos);
        adaptador = new Adaptador(GetListItems(), getContext());

        listaFavoritos.setAdapter(adaptador);


        //-----------------------------------------------------------------------------
        return v;
    }

    private ArrayList<Entidad> GetListItems(){

        ArrayList<Entidad> listaItems = new ArrayList<>();
        // CONEXION A LA BASE DE DATOS: SQLite
        MotorBaseDatosSQLite conector = new MotorBaseDatosSQLite(getContext(),"bdMyJacketShop", null, 1);
        SQLiteDatabase db_leer = conector.getReadableDatabase();
        Cursor cursor = db_leer.rawQuery("SELECT * FROM favoritos", null);
        //conector.onUpgrade(db_leer, 1, 2);

        while(cursor.moveToNext()){
            listaItems.add(new Entidad(Uri.parse(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3)));
        }

        return listaItems;
    }
}