package usa.sesion15.reto4.Vista;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;

import reto4.R;
import usa.sesion15.reto4.Modelo.Adaptador;
import usa.sesion15.reto4.Modelo.BaseDatos.MotorBaseDatosSQLite;
import usa.sesion15.reto4.Modelo.Entidad;

public class Fragment_Sucursales extends Fragment {

    View v;
    ListView listaSucursales;
    Adaptador adaptador;
    Uri imageUri1, imageUri2, imageUri3;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment__sucursales, container, false);
        //-----------------------------------------------------------------------------
        listaSucursales = (ListView) v.findViewById(R.id.lista_sucursales);
        adaptador = new Adaptador(GetListItems(), getContext());

        listaSucursales.setAdapter(adaptador);

        //-----------------------------------------------------------------------------
        return v;
    }
    private ArrayList<Entidad> GetListItems(){
        //imageUri1 = Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.drawable.sucursal1);
        //imageUri2 = Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.drawable.sucursal2);
        //imageUri3 = Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.drawable.sucursal3);
        ArrayList<Entidad> listaItems = new ArrayList<>();

        // CONEXION A LA BASE DE DATOS: SQLite
        MotorBaseDatosSQLite conector = new MotorBaseDatosSQLite(getContext(),"bdMyJacketShop", null, 1);
        SQLiteDatabase db_leer = conector.getReadableDatabase();
        conector.onUpgrade(db_leer, 1, 2);
        Cursor cursor = db_leer.rawQuery("SELECT * FROM sucursales", null);

        while(cursor.moveToNext()){
            listaItems.add(new Entidad(Uri.parse(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3)));
        }

        //listaItems.add(new Entidad(imageUri1, "Sucursal Central", "Carrera #4 5- 32","Telefono: 3123322156"));
        //listaItems.add(new Entidad(imageUri2, "Sucursal Alterna 1", "Calle #65 12-43","Telefono: 3134675544"));
        //listaItems.add(new Entidad(imageUri3, "Sucursal Alterna 2", "Carrera #125 45-02","Telefono: 3565453332"));
        return listaItems;
    }

}