package usa.sesion15.reto4.Vista;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import org.osmdroid.config.Configuration;
import org.osmdroid.library.BuildConfig;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.ItemizedIconOverlay;
import org.osmdroid.views.overlay.ItemizedOverlayWithFocus;
import org.osmdroid.views.overlay.OverlayItem;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.util.ArrayList;

import reto4.R;
import usa.sesion15.reto4.Modelo.BaseDatos.MotorBaseDatosSQLite;
import usa.sesion15.reto4.Modelo.Entidad;

public class Fragment_Mapa extends Fragment {

    View v;

    private MapView myOpenMapView;
    private MapController myMapController;
    GeoPoint Bogota, Medellin, Tunja;
    //ListView listaSucursales;
    //Adaptador adaptador;
    //Uri imageUri1, imageUri2, imageUri3;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment__mapa, container, false);
        //-----------------------------------------------------------------------------
        //listaSucursales = (ListView) v.findViewById(R.id.lista_sucursales);
        //adaptador = new Adaptador(GetListItems(), getContext());
        //listaSucursales.setAdapter(adaptador);

        myOpenMapView = (MapView) v.findViewById(R.id.openmapview);

        /* ---- necesitamos establecer el valor del agente de usuario en la configuración ------- */
        Configuration.getInstance().setUserAgentValue(BuildConfig.APPLICATION_ID);

        /*   punto de geolocalizacion de ejemplo */
        /*   punto de geolocalizacion de ejemplo */
        Bogota = new GeoPoint(4.650452, -74.071641);
        Medellin = new GeoPoint(6.250815, -75.5666633);
        Tunja = new GeoPoint(5.531647,  -73.360533);



        myOpenMapView.setBuiltInZoomControls(true);

        myMapController = (MapController) myOpenMapView.getController();
        myMapController.setCenter(Bogota);
        myMapController.setZoom(6);

        myOpenMapView.setMultiTouchControls(true);

        /* -------------------------------------------------------------------------------------------------- */
        final MyLocationNewOverlay myLocationoverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(getContext()), myOpenMapView);
        myOpenMapView.getOverlays().add(myLocationoverlay); //No añadir si no quieres una marca
        myLocationoverlay.enableMyLocation();

        myLocationoverlay.runOnFirstFix(new Runnable() {
            public void run() {
                myMapController.animateTo(myLocationoverlay.getMyLocation());
            }
        });

        /* MARCAS EN EL MAPA */

        ArrayList<OverlayItem> puntos = new ArrayList<OverlayItem>();
        puntos.add(new OverlayItem("Sucursal Central", "Bogotá - Cll #3 5- 32", Bogota));
        puntos.add(new OverlayItem("Sucursal Alterna 1", "Medellín - Av.Palacé #52-2", Medellin));
        puntos.add(new OverlayItem("Sucursal Alterna 2", "Tunja - Cll. 19 #8-131", Tunja));

        ItemizedIconOverlay.OnItemGestureListener<OverlayItem> tap = new ItemizedIconOverlay.OnItemGestureListener<OverlayItem>() {
            @Override
            public boolean onItemLongPress(int arg0, OverlayItem arg1) {
                return false;
            }
            @Override
            public boolean onItemSingleTapUp(int index, OverlayItem item) {
                return true;
            }
        };

        ItemizedOverlayWithFocus<OverlayItem> capa = new ItemizedOverlayWithFocus<OverlayItem>(getContext(), puntos, tap);
        capa.setFocusItemsOnTap(true);
        myOpenMapView.getOverlays().add(capa);


        //-----------------------------------------------------------------------------
        return v;
    }
    private ArrayList<Entidad> GetListItems(){
        //imageUri1 = Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.drawable.sucursal1);
        //imageUri2 = Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.drawable.sucursal2);
        //imageUri3 = Uri.parse("android.resource://" + getContext().getPackageName() + "/" + R.drawable.sucursal3);
        ArrayList<Entidad> listaItems = new ArrayList<>();

        // CONEXION A LA BASE DE DATOS: SQLite
        MotorBaseDatosSQLite conector = new MotorBaseDatosSQLite(getContext(),"bdMyJacketShop", null, 1);
        SQLiteDatabase db_leer = conector.getReadableDatabase();
        conector.onUpgrade(db_leer, 1, 2);
        Cursor cursor = db_leer.rawQuery("SELECT * FROM sucursales", null);

        while(cursor.moveToNext()){
            listaItems.add(new Entidad(Uri.parse(cursor.getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3)));
        }

        //listaItems.add(new Entidad(imageUri1, "Sucursal Central", "Carrera #4 5- 32","Telefono: 3123322156"));
        //listaItems.add(new Entidad(imageUri2, "Sucursal Alterna 1", "Calle #65 12-43","Telefono: 3134675544"));
        //listaItems.add(new Entidad(imageUri3, "Sucursal Alterna 2", "Carrera #125 45-02","Telefono: 3565453332"));
        return listaItems;
    }
}